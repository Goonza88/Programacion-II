package tp1.java;

import java.util.Scanner;

/**
 * @author Gonza
 */

public class TP1Java {
    public static void main(String[] args) {
        ejercicio3();
        ejercicio4(); 
        ejercicio5();
        ejercicio6();
        ejercicio7();
        ejercicio8();
        ejercicio9();
    }
   
    public static void ejercicio3() {
        String nombre;
        int edad;
        double altura;
        boolean estudiante;
        
        nombre = "Gonzalo";
        edad = 24;
        altura = 1.75;
        estudiante = true;
        
        System.out.println(nombre);
        System.out.println(edad);
        System.out.println(altura);
        System.out.println(estudiante);
    }
    
    public static void ejercicio4() {
        Scanner input = new Scanner(System.in);
        String nombre;
        int edad;
        
        System.out.print("Ingresa tu nombre: ");
        nombre = input.nextLine();
        
        System.out.print("Ingresa tu edad: ");
        edad = Integer.parseInt(input.nextLine());
        
        System.out.println("Tu nombre es " + nombre);
        System.out.println("Tu edad es " + edad);
    }
    
    public static void ejercicio5() {
        Scanner input = new Scanner(System.in);
        int num1, num2;
        
        System.out.println("Ingrese un numero entero: ");
        num1 = Integer.parseInt(input.nextLine());
        
        System.out.println("Ingrese otro numero entero: ");
        num2 = Integer.parseInt(input.nextLine());
        
        System.out.println("Resultados: ");
        System.out.println("Suma: " + (num1 + num2));
        System.out.println("Resta: " + (num1 - num2));
        System.out.println("Multiplicacion: " + (num1 * num2));
        System.out.println("Division: " + ((double)num1 / num2));
    }
    
    public static void ejercicio6() {
        String nombre = "Juan Pérez", direccion = "Calle Falsa 123";
        int edad = 30;
        
        System.out.println("Nombre: " + nombre + "\nEdad: " + edad + "\nDirección: " + direccion);
    }
    
    public static void ejercicio7() {
       /*
        int x = 10; // Línea 1
        x = x + 5; // Línea 2
        System.out.println(x); // Línea 3
        
        
         Linea 1 es una expresion, porque simplemente esta definiendo que x es 10.
         Linea 2 y 3 son instrucciones, porque le estas pidiendo al programa que 
         realice ciertas acciones que dan un resultado.
        */
    }
   
    public static void ejercicio8() {
        Scanner input = new Scanner(System.in);
        int num1, num2;
        
        System.out.println("Ingrese un numero entero: ");
        num1 = Integer.parseInt(input.nextLine());
        
        System.out.println("Ingrese otro numero entero: ");
        num2 = Integer.parseInt(input.nextLine());
        
        System.out.println("Resultados: ");
        System.out.println("Division sin double: " + (num1 / num2));
        System.out.println("Division con double: " + ((double)num1 / num2));
    }
     
    
    public static void ejercicio9() {
        //   ORIGINAL:
        /* 
        import java.util.Scanner;
        
        public class ErrorEjemplo {
            public static void main(String[] args) {
                Scanner scanner = new Scanner(System.in);
                System.out.print("Ingresa tu nombre: ");
                String nombre = scanner.nextInt(); // ERROR
                System.out.println("Hola, " + nombre);
             }
         }
        */
        //   CORREGIDO:
        /* 
         import java.util.Scanner;

         public class ErrorEjemplo {
             public static void main(String[] args) {
                 Scanner input = new Scanner(System.in); // Cambie "scanner" por "input"
                 System.out.println("Ingresa tu nombre: "); // ".println" estaba sin el "ln"
                 String nombre = input.nextLine(); // ERROR // Cambien "scanner.nextInt();" por "input.nextLine()"
                 System.out.println("Hola, " + nombre);
              }
         }
         */
        // TEST:
        Scanner input = new Scanner(System.in); 
        System.out.println("Ingresa tu nombre: "); 
        String nombre = input.nextLine(); 
        System.out.println("Hola, " + nombre);
    }
}
    

