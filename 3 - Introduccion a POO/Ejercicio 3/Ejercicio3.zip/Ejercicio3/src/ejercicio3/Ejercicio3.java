package ejercicio3;

/**
 * @author Gonza
 */
public class Ejercicio3 {
    public static void main(String[] args) {
        Libro l = new Libro();
        
        l.setAño(1700);
        l.mostrarInfo();
        l.setAño(500);
        l.mostrarInfo();
        l.setAño(2620);
        l.mostrarInfo();
    }
}
