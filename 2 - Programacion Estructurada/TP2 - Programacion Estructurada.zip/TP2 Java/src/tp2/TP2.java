/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tp2;

import java.util.Scanner;

/**
 *
 * @author Gonza
 */
public class TP2 {
    static double descuentoEspecial = 0.10;
    
      public static void main(String[] args) {
          Scanner input = new Scanner(System.in);
          ejercicio1();
          ejercicio2();
          ejercicio3();
          ejercicio4();
          ejercicio5();
          ejercicio6();
          ejercicio7();
          System.out.println("Ejercicio 8: ");
          double precioBase, impuesto, descuento, resultado;

          System.out.print("Ingrese el precio base del producto: ");
          precioBase = Double.parseDouble(input.nextLine());

          System.out.print("Ingrese el impuesto en porcentaje (Ejemplo: 10 para 10%): ");
          impuesto = Double.parseDouble(input.nextLine());

          System.out.print("Ingrese el descuento en porcentaje (Ejemplo: 5 para 5%): ");
          descuento = Double.parseDouble(input.nextLine());

          resultado = calcularPrecioFinal(precioBase, impuesto, descuento);

          System.out.println("El precio final del producto es: " + resultado);
      
          System.out.println("Ejercicio 9: ");
          double precio, peso, opcion, totalCompra, costoEnvio;
          
          System.out.print("Ingrese el precio del producto: ");
          precio = Double.parseDouble(input.nextLine());
          
          System.out.print("Ingrese el peso del producto(kg): ");
          peso = Double.parseDouble(input.nextLine());
          
          do {
              System.out.print("Ingrese si es envio Nacional(1) o Internacional(2): ");
              opcion = Integer.parseInt(input.nextLine());
              
              costoEnvio = calcularCostoEnvio(peso, opcion);
              
          } while (opcion != 1 && opcion != 2);
          
          totalCompra = calcularTotalCompra(precio, costoEnvio);
          
          System.out.println("El costo de envio es: " + costoEnvio);
          System.out.println("El total a pagar es: " + totalCompra);
          
          System.out.println("Ejercicio 10: ");
          double sAct, sVend, sRec, sNuevo;
          
          System.out.print("Ingrese el stock actual: ");
          sAct = Double.parseDouble(input.nextLine());
          
          System.out.print("Ingrese la cantidad vendida: ");
          sVend = Double.parseDouble(input.nextLine());
          
          System.out.print("Ingrese la cantidad recibida: ");
          sRec = Double.parseDouble(input.nextLine());
          
          sNuevo = actualizarStock(sAct, sVend, sRec);
          
         System.out.println("El nuevo stock del producto es :" + sNuevo);
         
          System.out.println("Ejercicio 11: ");
          double precioEsp;
          
          System.out.print("Ingrese el precio: ");
          precioEsp = Double.parseDouble(input.nextLine());
       
          calcularDescuentoEspecial(precioEsp);
          
          ejercicio12();
          ejercicio13();

    }

      public static void ejercicio1() {
          System.out.println("Ejercicio 1:");
          Scanner input = new Scanner(System.in);
          int año;
        
          System.out.print("Ingrese un año: ");
          año = Integer.parseInt(input.nextLine());

          if ((año % 4 == 0 && año % 100 != 0) || (año % 400 == 0)) {
              System.out.println("El año " + año + " es bisiesto.");
          } else {
              System.out.println("El año " + año + " no es bisiesto.");
          }
     }
     
      public static void ejercicio2() { 
          System.out.println("Ejercicio 2:");
          Scanner input = new Scanner(System.in);
          int num1, num2, num3, mayor;
        
          System.out.print("Ingrese el primer numero entero: ");
          num1 = Integer.parseInt(input.nextLine());
          
          System.out.print("Ingrese el segundo numero entero: ");
          num2 = Integer.parseInt(input.nextLine());
          
          System.out.print("Ingrese el tercer numero entero: ");
          num3 = Integer.parseInt(input.nextLine());
          
          if (num1 >= num2 && num1 >= num3) {
              mayor = num1;
          } else if (num2 >= num1 && num2 >= num3) {
              mayor = num2;
          } else {
              mayor = num3;
          }

          System.out.println("El mayor es: " + mayor);
     }
     
      public static void ejercicio3() { 
          System.out.println("Ejercicio 3:");
          Scanner input = new Scanner(System.in);
          int edad;
        
          System.out.print("Ingrese su edad: ");
          edad = Integer.parseInt(input.nextLine());
          
           if (edad >= 0 && edad <= 11) {
              System.out.println("Niño");
          } else if (edad >= 12 && edad <= 17) {
              System.out.println("Adolescente");
          } else if (edad >= 18 && edad <= 59) {
              System.out.println("Adulto");
          } else {
              System.out.println("Adulto mayor");              
          }
     }
     
      public static void ejercicio4() {
          System.out.println("Ejercicio 4:");
          Scanner input = new Scanner(System.in);
          int precio;
          double descuento, descuentoTotal, precioFinal;
          char categoria;
          
          System.out.print("Ingrese el precio del producto: ");
          precio = Integer.parseInt(input.nextLine());

          System.out.print("Ingrese la categoria del producto (A, B o C): ");
          categoria = input.next().toUpperCase().charAt(0);

          switch (categoria) {
               case 'A' -> descuento = 0.10;
               case 'B' -> descuento = 0.15;
               case 'C' -> descuento = 0.20;
               default -> {
                    System.out.println("Categoria Erronea");
                    return; 
               }
          }

          descuentoTotal = precio * descuento;
          precioFinal = precio - descuentoTotal;

          System.out.println("Descuento aplicado: " + (descuento * 100) + "%");
          System.out.println("Precio final: " + precioFinal);
      }
      
      public static void ejercicio5() {
          System.out.println("Ejercicio 5:");
          Scanner input = new Scanner(System.in);
          int num1 = 1, num2 = 0;
          
          while (num1 != 0) {
              System.out.print("Ingrese un numero (0 para terminar): ");
              num1 = Integer.parseInt(input.nextLine());
              
              if (num1 % 2 == 0) {
                  num2 += num1;
              }
          }
          System.out.println("La suma de los numeros pares es: " + num2);
      }
      
      public static void ejercicio6() {
          System.out.println("Ejercicio 6:");
          Scanner input = new Scanner(System.in);
          int neg = 0, pos = 0, ceros = 0, num;
          
          for (int i = 1; i <= 10; i++) {
              System.out.print("Ingrese el numero " + i + ": ");
              num = Integer.parseInt(input.nextLine());

              if (num > 0) {
                  pos++;
              } else if (num < 0) {
                  neg++;
              } else {
                  ceros++;
              }
          }
          
          System.out.println("Resultados:");
          System.out.println("Positivos: " + pos);
          System.out.println("Negativos: " + neg);
          System.out.println("Ceros: " + ceros);
      }
     
      public static void ejercicio7() {
          System.out.println("Ejercicio 7:");
          Scanner input = new Scanner(System.in);
          int nota;
          
          do {
              System.out.print("Ingrese una nota (0-10): ");
              nota = Integer.parseInt(input.nextLine());
              
              if (nota < 0 || nota > 10) {
                  System.out.println("Error: Nota invalida. Ingrese una nota entre 0 y 10.");
              }
              
          } while (nota < 0 || nota > 10);
          
          System.out.println("Nota guardada correctamente");
      }

      public static double calcularPrecioFinal(double precioBase, double impuesto, double descuento) {
          double precioFinal = precioBase + (precioBase * (impuesto / 100)) - (precioBase * (descuento / 100));
          return precioFinal;
      }

      public static double calcularCostoEnvio(double peso, double opcion) {
          if (opcion == 1) {
              return peso * 5;
          } else {
              return peso * 10;
          }
      }
      
      public static double calcularTotalCompra(double precio, double costoEnvio) {
          return precio + costoEnvio;
      }

      public static double actualizarStock(double sAct, double sVend, double sRec) {
          return sAct - sVend + sRec;
      }
      
      public static void calcularDescuentoEspecial(double precioEsp) {
          double descuentoAplicado, precioTotal;
          
          descuentoAplicado = precioEsp * descuentoEspecial;
          precioTotal = precioEsp - descuentoAplicado;
          
          System.out.println("El descuento especial aplicado es: " + descuentoAplicado);
          System.out.println("El precio final con descuento es: " + precioTotal);
      }

      public static void ejercicio12() {
          System.out.println("Ejercicio 12:");
          double[] precios = {99.99, 599.5, 1500.75, 399.0, 89.99};

          System.out.println("Precios originales:");
          for (double precio : precios) {
              System.out.println("Precio: $" + precio);
          }

          precios[0] = 129.50;
          precios[2] = 139.25;
          precios[4] = 1200.00;

          System.out.println("\nPrecios modificados:");
          for (double precio : precios) {
              System.out.println("Precio: $" + precio);
          }
       }

      public static void ejercicio13() {
          System.out.println("Ejercicio 13:");
          double[] precios = {99.99, 599.5, 1500.75, 399.0, 89.99};

          System.out.println("Precios originales:");
          funcionRecursiva(precios, 0);

          precios[4] = 129.50;
          precios[2] = 139.25;
          precios[0] = 1200.00;

          System.out.println("\nPrecios modificados:");
          funcionRecursiva(precios, 0);
      }
      
      public static void funcionRecursiva(double[] precios, int contador) {
          if (contador < precios.length) {
              System.out.println("Precio: $" + precios[contador]);
              funcionRecursiva(precios, contador + 1 );  
          }
      }
}
